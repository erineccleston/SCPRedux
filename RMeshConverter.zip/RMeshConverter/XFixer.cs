// Written by ErinPone, 6/25/2017

using System;
using System.IO;
using System.Text.RegularExpressions;

namespace XFixer
{
    class XFixer
    {
        static void Main(string[] args)
        {
            string materialPattern = @"Material dx_brush0 {
   1.000000;1.000000;1.000000;1.000000;;
   0.000000;
   1.000000;1.000000;1.000000;;
   0.000000;0.000000;0.000000;;
   TextureFilename {
      """";
   }
}";

            Console.Write("Path to all files: ");
            string path = Console.ReadLine();
            Console.WriteLine("\n");

            string[] files = Directory.GetFiles(path);
            Directory.CreateDirectory(path + "\\XFixed");

            foreach (string file in files)
            {
                Console.WriteLine("Found: " + file);

                string contents = File.ReadAllText(file);

                int numGroups = Regex.Matches(contents, "dx_brush").Count - 1;

                contents = Regex.Replace(contents, materialPattern, "//materials here");

                contents = Regex.Replace(contents, "dx_brush.", "REPLACEME");

                Regex reg = new Regex("REPLACEME");
                for (int i = 0; i < numGroups; i ++)
                {
                    contents = reg.Replace(contents, "Material" + i, 1);
                    contents = contents.Insert(contents.IndexOf('}') + 1, "\n" + materialPattern);
                    contents = Regex.Replace(contents, "dx_brush0", "Material" + ((i - numGroups + 1) * -1));
                }

                string outPath = path + "\\XFixed" + file.Substring(file.LastIndexOf('\\'));
                File.WriteAllText(outPath, contents);
                Console.WriteLine("Wrote: " + outPath);
                Console.WriteLine();
            }

            Console.WriteLine();
            Console.Write("Press enter to exit...");
            Console.ReadLine();
        }
    }
}
