Instructions for converting from .rmesh to .x to .fbx:

Download Blitz3D (https://nitrologic.itch.io/blitz3d) and the SCP-CB source code (https://github.com/Regalis11/scpcb).
Install Blitz3D and extract the SCP-CB source code.
Replace RMesh_Model_Viewer.bb in the source code folder with the one in this folder.
Open the GFX/map folder in the source code folder.
If you want the maintaenance tunnel meshes (mt*.rmesh), rename them to mt*_opt.rmesh
If you want GFX\map\dimension1499\1499object0_opt.rmesh, move it into GFX\map
Open RMesh_Model_Viewer.bb with Blitz3D and run it (Program>Run Program).
Enter the name of each file WITHOUT _opt.rmesh at the end. You don't need the non-_opt version.
Unfortunately I couldn't figure out how to make the cursor go to a newline, so you'll have to type blind.
If the program crashes (which it will if you misspell a filename), restart it.
Now all the .x files will be in the 'converted' folder in the source code folder.

These .x files have all their shader groups assigned, but they all point to the same material due to some bug in RMesh_Model_Viewer.bb so they need to be fixed.
Compile and run XFixer.cs. (You already have Visual Studio, right?) 
Input the path to the folder containing the .x files from earlier starting from the root of your drive (e.g. C:\Users\Erin\Desktop\scpcb-master\converted).
This program shouldn't crash (though it might if you have non-.x files in the converted folder).
There will now be an 'XFixed' folder inside the 'converted' folder. This contains the fixed .x files ready for conversion.

To convert the .x files into something more common, I'd recommend fragMOTION (http://www.fragmosoft.com/fragMOTION/) because it usually preserves shader groups.
Yes, you have to type the Lord's Prayer to get it to activate. Yes, that's really fucking weird. Deal with it.
With fragMOTION installed, go to File>Batch Convert..., choose a destination directory and an output format, add the fixed .x files, and Convert them.
FragMOTION sometimes crashes with large batches, so kill it with Task Manager if it hangs, then find the last file it successfully converted and start again from there.

Congratulations, you now have usable files with the correct shader groups. Import them into your favorite engine and use trial and error to import them with the right 
dimensions and rotation and to see what material should be assigned to which shader group.



Here's some tips for importing into Unreal Engine:
Untick the Skeletal Mesh box (because they're static meshes).
Set Normal Import Method to Compute Normals.
Set Normal Generation Method to Built In. (I got some errors when it was set to Mikk TSpace, but I don't know if that actually affected anything.)
Set Import Uniform Scale to -1.0 (something about .x files or fragMOTION causes them to be inverted) and Import Rotation>X to 180.0.
Also untick Import Materials and Import Textures.
The shader groups don't have meaningful names so you'll have to use trial and error to assign the right material. (The Isolate checkbox next to each material in the 
Details panel of the static mesh viewer is helpful for this.)



This guide was written by ErinPone, developer of the Unreal Engine port of SCP - Containment Breach.
Forum Thread (https://undertowgames.com/forum/viewtopic.php?f=3&t=7325)
GameJolt Download (http://gamejolt.com/games/SCPUnreal/259576)
Discord (https://discord.gg/KjUuzNV)
Patreon (https://www.patreon.com/ParagonAM)